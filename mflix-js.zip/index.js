require("babel-core/register")
require("dotenv").config()

exports = module.exports = require("./src")
